package hotelbookingserviceproducer;

public interface HotelServiceProduce {
	
	public String publishService();
}
