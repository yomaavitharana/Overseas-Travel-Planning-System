package mealservicepublisher;

public interface ServicePublish {
	
	public String publishService();
}
