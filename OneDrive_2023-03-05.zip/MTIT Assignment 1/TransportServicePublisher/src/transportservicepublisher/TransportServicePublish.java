package transportservicepublisher;

public interface TransportServicePublish {
	
	public String publishService();
}
