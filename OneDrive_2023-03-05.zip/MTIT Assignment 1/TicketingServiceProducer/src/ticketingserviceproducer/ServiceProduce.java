package ticketingserviceproducer;

public interface ServiceProduce {
	
	public String publishService();
}
